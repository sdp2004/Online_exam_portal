/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package onlineexamportal1;






import static java.lang.Class.forName;
import  com.mysql.cj.xdevapi.Statement;

import java.sql.Connection;
import static java.sql.DriverManager.getConnection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import static java.util.logging.Level.SEVERE;
import java.util.logging.Logger;
import static java.util.logging.Logger.getLogger;
import javax.swing.JOptionPane;

/**
 *
 * @author Soumi Pal
 */
public class Test extends javax.swing.JFrame {

    /**
     * Creates new form question
     */
    public Test() {
        initComponents();
       
        Connect();
        LoadQuestions();
        
    }
    
    int answerCheck=0;
    int marks=0;
    String cor=null;
    String answer=null;
    java.sql.Statement stat;
    
    public boolean answerCheck()
    {
        String Answerans="";
        if(ans1.isSelected())
        {
            Answerans=ans1.getText();
        }
        else if(ans2.isSelected())
        {
            Answerans=ans2.getText();
        }
        else if(ans3.isSelected())
        {
            Answerans=ans3.getText();
        }
        else if(ans4.isSelected())
        {
            Answerans=ans4.getText();
        }
        if (Answerans.equals(cor) && (answer==null || !answer.equals(cor)))
        {
            marks=marks+1;
            txtmarks.setText(String.valueOf(marks));
        }
        else if (!Answerans.equals(cor) && answer!=null)
        {
            if(marks>0)
            {
                marks=marks-1;
            }
            txtmarks.setText(String.valueOf(marks));
        }
        if(!Answerans.equals(""))
        {
            try
            {
                String query="UPDATE question SET givenanswer=? WHERE question=?";
                pst=con.prepareStatement(query);
                pst.setString(1, Answerans);
                pst.setString(2, jLabel3.getText());
                pst.execute();
            }
            catch(SQLException ex)
            {
                ex.printStackTrace();
            }
            return true;
        }
        return false;
    }
    
    private void NULLALLGivenAnswer()
    {
        try
            {
                String query="UPDATE question SET givenanswer=?";
                pst=con.prepareStatement(query);
                pst.setString(1, null);
                pst.execute();
            }
            catch(SQLException e)
            {
                e.printStackTrace();
            }
    }
    
    private boolean AlreadyAnswered()
    {
        
        try {
            String query="SELECT givenanswer FROM question WHERE question= '"+jLabel3.getText()+"'";
            stat= con.prepareStatement(query);
            ResultSet res=stat.executeQuery(query);
            while(res.next())
            {
                answer=res.getString("givenanswer");
                if(answer==null)
                {
                    return false;
                }
                break;
            }
            if (ans1.getText().equals(answer))
            {
                ans1.setSelected(true);
            }
            
            else if (ans2.getText().equals(answer))
            {
                ans2.setSelected(true);
            }
            else if (ans3.getText().equals(answer))
            {
                ans3.setSelected(true);
            }
            else if (ans4.getText().equals(answer))
            {
                ans4.setSelected(true);
            }



        } catch (SQLException ex) {
            System.out.println("Exception Caught");
            ex.printStackTrace();
        }
        return true;
    }
    Connection con;
    PreparedStatement pst;
    ResultSet rs;
    public void Connect()
    {
       
        try {
            forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            getLogger(Student.class.getName()).log(SEVERE, null, ex);
        }
        try {
            con=getConnection("jdbc:mysql://localhost:3306/onlineexam","root","");
        } catch (SQLException ex) {
            getLogger(Student.class.getName()).log(SEVERE, null, ex);
        }
    }
    
    public void LoadQuestions() 
    {
        String query="select * from question";
             
        java.sql.Statement stat=null; 
        try {
             
             stat= con.createStatement();
             rs=stat.executeQuery(query);
           
            while(rs.next())
            {
                jLabel4.setText(rs.getString(1));
                jLabel3.setText(rs.getString(2));
                ans1.setText(rs.getString(3));
                ans2.setText(rs.getString(4));
                ans3.setText(rs.getString(5));
                ans4.setText(rs.getString(6));
                cor=rs.getString(7);
                
                break;
            }
        } catch (SQLException ex) {
            Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        ans2 = new javax.swing.JRadioButton();
        ans1 = new javax.swing.JRadioButton();
        ans3 = new javax.swing.JRadioButton();
        ans4 = new javax.swing.JRadioButton();
        jLabel1 = new javax.swing.JLabel();
        txtmarks = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        buttonGroup1.add(ans2);
        ans2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        ans2.setText("jRadioButton2");
        ans2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ans2ActionPerformed(evt);
            }
        });

        buttonGroup1.add(ans1);
        ans1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        ans1.setText("jRadioButton1");
        ans1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ans1ActionPerformed(evt);
            }
        });

        buttonGroup1.add(ans3);
        ans3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        ans3.setText("jRadioButton3");
        ans3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ans3ActionPerformed(evt);
            }
        });

        buttonGroup1.add(ans4);
        ans4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        ans4.setText("jRadioButton4");
        ans4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ans4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ans2)
                            .addComponent(ans1)
                            .addComponent(ans3))
                        .addContainerGap(350, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(ans4)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(63, 63, 63)
                .addComponent(ans1)
                .addGap(91, 91, 91)
                .addComponent(ans2)
                .addGap(91, 91, 91)
                .addComponent(ans3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 86, Short.MAX_VALUE)
                .addComponent(ans4)
                .addGap(68, 68, 68))
        );

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 51, 51));
        jLabel1.setText("Online Exam");

        txtmarks.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        txtmarks.setForeground(new java.awt.Color(51, 51, 255));
        txtmarks.setText("Marks");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(51, 51, 255));
        jLabel3.setText("Question");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(51, 51, 255));
        jLabel4.setText("No.");

        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton1.setText(" Next");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addComponent(jLabel3)
                        .addGap(328, 328, 328)
                        .addComponent(jLabel4))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(188, 188, 188)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(62, 62, 62)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(79, 79, 79)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtmarks)))
                .addContainerGap(78, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jLabel1)
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4))
                .addGap(51, 51, 51)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 38, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtmarks)
                .addGap(58, 58, 58))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ans4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ans4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ans4ActionPerformed

    private void ans3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ans3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ans3ActionPerformed

    private void ans2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ans2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ans2ActionPerformed

    private void ans1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ans1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ans1ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        
        if(answerCheck())
        {
            try
            {
                if(rs.next())
                {
                    jLabel3.setText(rs.getString("question"));
                    ans1.setText(rs.getString(3));
                    ans2.setText(rs.getString(4));
                    ans3.setText(rs.getString(5));
                    ans4.setText(rs.getString(6));
                 cor=rs.getString(7);
                 
                 if(!AlreadyAnswered())
                 {
                     buttonGroup1.clearSelection();
                 }
                 else
                 {
                     JOptionPane.showMessageDialog(this,"This the first record of the student.");
                 }
                }
            }
            catch(SQLException ex)
            {
                ex.printStackTrace();
            }
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Test.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Test.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Test.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Test.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Test().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton ans1;
    private javax.swing.JRadioButton ans2;
    private javax.swing.JRadioButton ans3;
    private javax.swing.JRadioButton ans4;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel txtmarks;
    // End of variables declaration//GEN-END:variables
}
